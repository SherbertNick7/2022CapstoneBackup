import csv
import datetime as dt
import os
import pandas as pd
import matplotlib.pyplot as plt
import glob
import time
import mpld3
import numpy as np

##This script is designed to find and detect the first instance of a series_event flag going high
##for an .csv file that holds archived frequency data. Because multiple files are sent to the RTAC
##in a single test, a 61 Hz buffer was employed to differentiate where each file starts and ends

def slew_calc(slew_window, ts_ph, Freq, file_name, memo={}):
    try:
        return memo[(slew_window, file_name)]
    except KeyError:
        sum_ts = []
        sum_freq = []
        sum_tsfreq = []
        sum_ts2 = []
        slew = []
        intercept = []
        line = []
        # print("slew window: ", slew_window)
        for j in range(len(Freq)):
            if j + slew_window > len(Freq):
                break
            else:
                sum_ts.append(np.sum(ts_ph[j:j + slew_window]))
                sum_freq.append(np.sum(Freq[j:j + slew_window]))
                sum_tsfreq.append(np.sum(ts_ph[j:j + slew_window] * Freq[j:j + slew_window]))
                sum_ts2.append(np.sum(ts_ph[j:j + slew_window] * ts_ph[j:j + slew_window]))
                slew.append((slew_window * sum_tsfreq[j] - sum_ts[j] * sum_freq[j]) / (
                slew_window * sum_ts2[j] - sum_ts[j] * sum_ts[j]))
                intercept.append((sum_freq[j] - slew[j] * sum_ts[j]) / slew_window)
                line.append(slew[j] * ts_ph[j] + intercept[j])
        memo[(slew_window, file_name)] = slew
        return slew


##Here the user will be prompted to select enter test name info
print("Enter the date test was ran: (mm-dd-yyyy): ")
todaysDate = input()
dateArray = todaysDate.split("-")
print("Enter test number for test date: ")
testNumber = input()
testName = todaysDate + " Test " + testNumber

# the order of csv files to be sent will be read from file path into array, line by line
testPath = "\\\\frespunraid.cecs.pdx.edu\\fresp\\Spring 2022 Capstone CSV test set\\Tests\\" + testName + "\\"
orderFilesSent = []  # declare array to be used for file order sent
with open(testPath + "FilesSent.txt") as fileSent:
    for j in fileSent:
        orderFilesSent.append(j)

testPath = testPath + "RTAC GS Recordings\\"#r"\\frespunraid.cecs.pdx.edu\\fresp\\Spring 2022 Capstone CSV test set\\Tests\\" + "RTAC GS Recordings\\"
testPath = testPath + dateArray[2] + "-" + dateArray[0] + "-" + dateArray[1] + "-*.csv" #"-*.csv"
print(testPath)

filePaths = glob.glob(testPath)
print(filePaths)

j = 0
k = 0
m = 0
bufferIteration = 1.0
endOfFile = False
nextInputFileDetected = False

print("HEY THERE, length: ",len(filePaths))
print("HEY THERE, length -1: ",len(filePaths) - 1)
print("HEY THERE, orderFilesSent -1: ",len(orderFilesSent) - 1)


print("buffer val: ",bufferIteration)

while bufferIteration <= (len(orderFilesSent) - 0):

    csvTimeArr = []
    csvFreqArr = []
    csvSlewArr = []
    csvSeriesEventArr = []

    while nextInputFileDetected == False:
        df = pd.read_csv(filePaths[k], encoding='cp1252')
        print("bufferIteration: ", bufferIteration)
        print("fileOpened: ", filePaths[k])
        print("press something please: ")
        print("K: ", k, "\n")
        i = 0
        for i, row in df.iterrows():
            freqVal = df.iloc[i, 1]  # 1 corresponds to freq column
            bufferActive = df.iloc[i, 4]  # 4 corresponds to buffer active column
            bufferCounter = df.iloc[i, 5]  # 5 corresponds to buffer counter column
            slewVal = df.iloc[i, 2]
            # print(slewVal)
            # print("The type is : ", type(slewVal))
            slewVal = str(slewVal)
            print("last char is: ", slewVal[-1], "at", i)
            if slewVal[-1].isdigit() == False:
                slewVal = slewVal[:-1]
            slewVal = float(slewVal)/1.0 ##TEMP! THE DIVIDE BY 100 IS A TEST!
            df.iloc[i, 2] = slewVal

            if (freqVal > 59.5) & (freqVal < 60.5) & (bufferActive != 1.0) & (bufferCounter == bufferIteration):
                print("we are in file: ", filePaths[k], " i is: ", i)
                print("The buffer iteration is: ", bufferIteration)
                csvTimeArr.append(df.iloc[i, 0])
                csvFreqArr.append(df.iloc[i, 1])
                csvSeriesEventArr.append(df.iloc[i, 3])
                csvSlewArr.append(df.iloc[i, 2])

            # if the last line of file is detected and the bufferActive is not active, then iterate
            # value k, and we will move on to next rtac recording file to keep filling in file array until next buffer active
            if (i == len(df) - 1):
                if (bufferCounter == bufferIteration) & (bufferActive == 0.0 or bufferActive == 1.0):
                    # print("is last row:", i == len(df) - 1)
                    # print("i: ", i)
                    # print("Before, K: ",k)
                    k = k + 1
                    # print("After, K: ",k,"\n")
                    # print("Buffer Iteration:", bufferIteration)
                    # print("File in dataframe: ", filePaths[k])
                    nextInputFileDetected = False

            # if the data we are looking at is preceding the next buffer data, then we are done finding
            # data for that input file and need to move on to plot it
            if (bufferIteration < bufferCounter) & (bufferActive != 1.0):
                print("i where next buffer ws found is", i, "in file", filePaths[k])
                nextInputFileDetected = True
                break


    archiveFreqArr = []
    archiveTimeStamp = []
    archiveFileToOpen = orderFilesSent[j]
    archiveFileToOpen = archiveFileToOpen[:-1] #remove hidden '\n' charachter at end of file path

    with  open(archiveFileToOpen) as csvArchivefile:  # opens the specific csv file in NERC directory
        csvArchivefileReader = csv.DictReader(csvArchivefile, delimiter=',')  # csv files have data seperated by commas
        for rows in csvArchivefileReader:  # for each row in csv, 'rows' denotes # of total rows?
            y = rows['STATION_1:Freq']  # access the freq column in each row, assign it to 'y
            z = rows['Timestamp']
            archiveFreqArr.append(float(y))
            archiveTimeStamp.append(z)

    archiveSlew = []
    # for m in range(len(archiveFileToOpen)):
    # fnm = name[i]
    # file_name.append(fnm)  # FIle name to save for writing out to csv to store Event=T/F & Under/Over frequency
    # # Creating the dataframe for the PMU csv file and Parsing data
    # df = pd.read_csv(nameOfCSV[i], delimiter=',', low_memory=False)
    df = pd.read_csv(archiveFileToOpen, delimiter=',', low_memory=False)

    print(df)
    # Timestamp = df['Timestamp']
    # freq_original.append(df['STATION_1:Freq'])
    print("length of freq array: ", len(archiveFreqArr))

    ts_ph = np.linspace(0, len(archiveFreqArr), len(archiveFreqArr))
    print("we are at slew line 1")
    archiveSlew.append(slew_calc(255, ts_ph, archiveFreqArr, archiveFileToOpen))
    print("we are at slew line 2")
    print(archiveSlew)
    print("length of slew is: ", len(archiveSlew[0]))
    print("The file opened is: ", archiveFileToOpen)

    maxArrayLengthRTAC = len(csvFreqArr)
    maxArchiveFreqLength = len(archiveFreqArr)
    maxArchiveSlewLength = len(archiveSlew[0])
    
    maxArrayDiff = max(maxArrayLengthRTAC,maxArchiveFreqLength,maxArchiveSlewLength)

    for m in range(maxArrayDiff-len(csvFreqArr)):
        csvFreqArr.append(np.nan)
        csvSlewArr.append(np.nan)
        csvSeriesEventArr.append(np.nan)
        csvTimeArr.append('')

    for m in range(maxArrayDiff-len(archiveFreqArr)):
        archiveFreqArr.append(np.nan)

    for m in range(maxArrayDiff-len(archiveSlew[0])):
        archiveSlew[0].append(np.nan)

    print("\nLength  of csvFreqArr: ", len(csvFreqArr))
    print("Length  of archiveFreqArray: ", len(archiveFreqArr))
    print("Length  of csvSlewArr: ", len(csvSlewArr))

    print("len of csvTimeArr: ", len(csvTimeArr))
    print("len of csvFreqArr: ", len(csvFreqArr))
    print("len of archiveFreqArr: ", len(archiveFreqArr))


    plotTitle = orderFilesSent[j].rsplit("\\", 1)[-1]
    plotTitle = plotTitle[:-5]
    print(plotTitle)

    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(18, 10))
    ax1.plot(csvTimeArr, csvFreqArr)
    ax1.plot(csvTimeArr, archiveFreqArr)
    ax1.set_xticks(csvTimeArr[::1000])
    ax1.set_xticklabels(csvTimeArr[::1000], rotation=45, fontsize=6)
    ax1.set_ylabel('Frequency (Hz)')
    ax1.set_ylim(59.8, 60.2)
    ax1.legend(['RTAC Output', 'Archive Data'])
    plt.setp(ax1.get_xticklabels(), visible=False)

    ax2.plot(csvTimeArr, csvSlewArr)
    ax2.plot(csvTimeArr, archiveSlew[0])
    ax2.set_xticks(csvTimeArr[::1000])
    ax2.set_xticklabels(csvTimeArr[::1000], rotation=45, fontsize=6)
    ax2.set_ylabel('Slew')
    ax2.set_ylim(-0.001, 0.001)
    plt.setp(ax2.get_xticklabels(), visible=False)

    ax3.scatter(x=csvTimeArr, y=csvSeriesEventArr, alpha=0.8, marker='+')  # , edgecolor = 'red')
    ax3.set_xticks(csvTimeArr[::1000])
    ax3.set_xticklabels(csvTimeArr[::1000], rotation=45, fontsize=6)
    ax3.set_ylabel('Series Event')
    ax3.set_ylim(0, 1.5)

    # testPath = "I:\\FRESP\\Spring 2022 Capstone CSV test set\\Tests\\" + testName + "\\" + "RTAC Plots" + "\\" + filePaths[j] + ".html"
    testPath = r"\\frespunraid.cecs.pdx.edu\\fresp\\Spring 2022 Capstone CSV test set\\Tests\\" + testName + "\\RTAC Plots\\"
    testPath = testPath + plotTitle + ".html"
    # testPath = testPath + "dateArray[2] + "-" + dateArray[0] + "-" + dateArray[1] + "-{}".format(j)" +".html" ##note this
    fig.suptitle(plotTitle, fontsize=12)
    # plt.show()
    with open(testPath, 'w') as pngFile:
        mpld3.save_html(fig, pngFile)

    j += 1

    bufferIteration = bufferIteration + 1
    nextInputFileDetected = False





    # diffFreqLength = len(csvFreqArr) - len(archiveFreqArr)
    # diffSlewLength = len(csvSlewArr) - len(archiveSlew[0])
    #
    # print("length of csvFreqArr ", len(csvFreqArr))
    # print("Difference Freq is", diffFreqLength)
    # print("length of csvSlewArr ", len(csvFreqArr))
    # print("Difference Slew is", diffSlewLength)
    #
    #
    # if diffFreqLength > 0:
    #     for m in range(diffFreqLength):
    #         archiveFreqArr.append(np.nan)
    #
    # if diffSlewLength > 0:
    #     for m in range(diffSlewLength):
    #         archiveSlew[0].append(np.nan)
    #
    # print("archive slew is: ", archiveSlew[0])
    # print("length of archive slew is: ", len(archiveSlew[0]))
    # # print("Length  of csvFreqArr: ", len(csvFreqArr))
    # # print("Length  of archiveFreqArray: ", len(archiveFreqArr))
    # # print("Length  of archiveTimeArray: ", len(archiveTimeStamp))
    # # print("Length  of csvSlewArr: ", len(csvSlewArr))
    # # print("Length  of archiveSlewArray: ", len(archiveSlew))
    # # print("Length  of archiveTimeArray: ", len(archiveTimeStamp))
    #
    # if diffFreqLength < 0:
    #     print("flipped diff: ", -1 * diffFreqLength)
    #     for n in range(-1 * diffFreqLength):
    #         csvFreqArr.append(np.nan)
    #         csvSlewArr.append(np.nan)
    #         csvSeriesEventArr.append(np.nan)
    #         csvTimeArr.append('')
    #         archiveSlew[0].append(np.nan)
    #
    # print("archive slew length: ", archiveSlew[0])
    # time.sleep(5)
    # if diffSlewLength < 0:
    #     print("flipped diff: ", -1 * diffSlewLength)
    #     for n in range(-1 * diffSlewLength):
    #         csvSlewArr.append(np.nan)
    #         csvFreqArr.append(np.nan)
    #         csvSeriesEventArr.append(np.nan)
    #         csvTimeArr.append('')
    #         archiveSlew[0].append(np.nan)
    # print("archive slew length: ", len(archiveSlew[0]))
    # # print("enter something")
    # # dummyVar = input()





# def slew_calc(slew_window, ts_ph, Freq, file_name, memo={}):
#     try:
#         return memo[(slew_window, file_name)]
#     except KeyError:
#         sum_ts = []
#         sum_freq = []
#         sum_tsfreq = []
#         sum_ts2 = []
#         slew = []
#         intercept = []
#         line = []
#         print("slew window: ", slew_window)
#         for j in range(len(Freq)):
#             if j + slew_window > len(Freq):
#                 break
#             else:
#                 sum_ts.append(np.sum(ts_ph[j:j + slew_window]))
#                 sum_freq.append(np.sum(Freq[j:j + slew_window]))
#                 sum_tsfreq.append(np.sum(ts_ph[j:j + slew_window] * Freq[j:j + slew_window]))
#                 sum_ts2.append(np.sum(ts_ph[j:j + slew_window] * ts_ph[j:j + slew_window]))
#                 slew.append((slew_window * sum_tsfreq[j] - sum_ts[j] * sum_freq[j]) / (
#                 slew_window * sum_ts2[j] - sum_ts[j] * sum_ts[j]))
#                 intercept.append((sum_freq[j] - slew[j] * sum_ts[j]) / slew_window)
#                 line.append(slew[j] * ts_ph[j] + intercept[j])
#         memo[(slew_window, file_name)] = slew
#         return slew


'''
for fp in filePaths:

    df = pd.read_csv(fp, encoding='cp1252')
    #load first rtac file into dataframe. Then loop though all files and concatenate all files into super dataframe
    # df = pd.read_csv(testPath + "RTAC GS Recordings\\" + rtacRecordings[0], encoding='cp1252')
    # for i in range(1, len(rtacRecordings)):
    #     dfNext= pd.read_csv(testPath + "RTAC GS Recordings\\" + rtacRecordings[i], encoding='cp1252')
    #     df= pd.concat([df, dfNext])


    print(df)
    ##define arrays to put event data into
    fileSentName = []
    csvTimeArr = []
    csvFreqArr = []
    csvSlewArr = []
    csvSeriesEventArr= []
    bufferIteration = 1.0

    for i, row in df.iterrows():
        freqVal = df.iloc[i,1]  #1 corresponds to freq column
        bufferActive = df.iloc[i,4] #4 corresponds to buffer active column
        bufferCounter = df.iloc[i,5] #5 corresponds to buffer counter column


        if (freqVal > 59.0) & (freqVal < 60.5) & (bufferActive < 1.0) & (bufferCounter ==  bufferIteration):
            csvTimeArr.append(df.iloc[i,0])
            csvFreqArr.append(df.iloc[i,1])
            csvSlewArr.append(df.iloc[i,2])
            csvSeriesEventArr.append(df.iloc[i,3])


    fileSentName = fp  #get the file name we are plotting



    fig, (ax1, ax2, ax3) = plt.subplots(3,1, figsize=(8,4))
    ax1.plot(csvTimeArr,csvFreqArr)
    ax1.set_xticks(csvTimeArr[::1000])
    ax1.set_xticklabels(csvTimeArr[::1000], rotation=45, Fontsize=6)
    # ax1.title.set_text('Frequency (Hz) vs Time')
    ax1.set_ylabel('Frequency (Hz)')
    ax1.set_ylim(59.6, 60.4)
    plt.setp(ax1.get_xticklabels(), visible=False)

    ax2.plot(csvTimeArr,csvSlewArr)
    ax2.set_xticks(csvTimeArr[::1000])
    ax2.set_xticklabels(csvTimeArr[::1000], rotation=45, Fontsize=6)
    ax2.set_ylabel('Slew')
    ax2.set_ylim(-0.1, 0.1)
    plt.setp(ax2.get_xticklabels(), visible=False)

    ax3.scatter(x=csvTimeArr, y=csvSeriesEventArr, alpha=0.3, marker='+', edgecolor = 'red')
    ax3.set_xticks(csvTimeArr[::1000])
    ax3.set_xticklabels(csvTimeArr[::1000], rotation=45, Fontsize=6)
    ax3.set_ylabel('Series Event')
    ax3.set_ylim(0, 1.5)

    testPath = "I:\\FRESP\\Spring 2022 Capstone CSV test set\\Tests\\" + testName + "\\" + "RTAC Plots" + "\\"
    testPath = testPath + dateArray[2] + "-" + dateArray[0] + "-" + dateArray[1] + "-{}".format(j) +".html" ##note this
    fig.suptitle(fileSentName, fontsize=12)
    plt.show()
    with open(testPath, 'w') as pngFile:
        mpld3.save_html(fig, pngFile)

    j+=1

    bufferIteration = bufferIteration + 1
'''
#     # plt.show()
