import csv
import socket                   #Import libraries
import time
import os
from datetime import datetime
import easygui
import math

from matplotlib import pyplot as plt


# os.nice(-20)

def conn():
    global s
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.settimeout(1000)
    s.connect(('192.168.0.149',5025)) # NHR 9410 IP address
    output = 'SYST:RWL\n'             # Lock the touch panel screen (Safety purpose)
    s.send(output.encode('utf-8'))    # For each SCPI command, it MUST encoded into utf-8.
    return s


def clos(s):                              # This function is meant to close the connection
    output5 = 'SYST:LOC\n'                # Unlock the touch panel screen
    s.send(output5.encode('utf-8'))
    s.close()                             # Close the connection

start_time = time.time()

def Gs(fileToSend):

    global x
    arr = [] #this will contain all frequency values, appeneded on one after the other
    with  open(f"NERC events/" + fileToSend) as csv_file: #opens the specific csv file in NERC directory
        csv_reader = csv.DictReader(csv_file, delimiter=',') #csv files have data seperated by commas
        for rows in csv_reader:                 # for each row in csv, 'rows' denotes # of total rows?
            y = rows['STATION_1:Freq']          #access the freq column in each row, assign it to 'y'
            arr.append(float(y)+0.01203651)     #append that 'y' value into the array of frequency values

    conn()                                      #call function to connect to NHR grid sim
    # s.send('FREQ 60.00 \n'.encode('utf-8'))
    s.send('MACR:LEAR 1 \n'.encode('utf-8'))
    # print("sent1")
    s.send('MACR:OPER:SYNC:INST1 SYNC \n'.encode('utf-8'))
    # print("sent2")
    s.send('MACR:LEAR 0 \n'.encode('utf-8'))
    # print("sent4")
    s.send('MACR:RUN \n'.encode('utf-8'))
    # print("sent5")n
    output2 = 'FREQ '
    liss = []
    freq_val = []
    p = 0
    for i in arr:                               #i is index of each freq value
        if 0 <= p <= 500:
            #x = 0.0500
            x = 0.052
        if 501 <= p <=1000:
            x = 0.0285
        if 1001 <= p <= 1500:
            x = 0.0285
        if 1501 <= p <= 2000:
            x = 0.0285
        if 2001 <= p <= 2500:
            x = 0.0275
        if 2501 <= p <= 3000:
            x = 0.0275
        if 3001 <= p <= 3500:
            x = 0.0275
        if 3501 <= p <= 4000:
            x = 0.0270
        if 4001 <= p <= 4500:
            x = 0.0270
        if 4501 <= p <= 5000:
            x = 0.0270
        if 5001 <= p <= 5500:
            x = 0.0265
        if 5501 <= p <= 6000:
            x = 0.0265
        if 6001 <= p <= 6500:
            x = 0.0265
        if 6501 <= p <= 7000:
            x = 0.0270
        if 7001 <= p <= 7500:
            x = 0.0270
        if 7501 <= p <= 8000:
            x = 0.0270
        if 8001 <= p <= 8500:
            x = 0.0270
        if 8501 <= p <= 9000:
            x = 0.0270
        if 9001 <= p <= 9500:
            x = 0.0270
        if 9501 <= p <= 10000:
            x = 0.0265
        if 10001 <= p <= 10500:
            x = 0.0265
        if 10501 <= p <= 11000:
            x = 0.0270
        if 11001 <= p <= 11500:
            x = 0.0270
        if 11501 <= p <= 12000:
            x = 0.0270
        if 12001 <= p <= 12500:
            x = 0.0270
        if 12501 <= p <= 13000:
            x = 0.0270
        if 13001 <= p <= 13501:
            x = 0.0270
        if 13501 <= p <= 14000:
            x = 0.0270
        if 14001 <= p <= 14500:
            x = 0.0270
        if 14501 <= p <= 15000:
            x = 0.0270
        if 15001 <= p <= 15500:
            x = 0.0270
        if 15501 <= p <= 16000:
            x = 0.0270
        if 16001 <= p <= 16500:
            x = 0.0270
        if 16501 <= p <= 17000:
            x = 0.0270
        if 17001 <= p <= 17500:
            x = 0.0270
        if 17501 <+ p <= 18000:
            x = 0.0270
        print('frequency value: ', i, "in file ", fileToSend)
        start_time = time.time()
        #print('Starting time is ',start_time)
        t_end = time.time() + x
        while time.time() < t_end:
             k = 1
        var = output2 + str(i) + '\n'
        #print(var)
        s.send(var.encode('utf-8'))
        end_time = time.time()
        # print('Time ends here ',end_time)
        # diff = end_time - start_time
        # print(diff)
        # diff_list = liss.append(diff)
        s.send('FREQ?\n'.encode('utf-8'))
        msg = s.recv(1024).decode()
        freq_val.append(msg)
        p = p + 1

        # print('response: ', msg)
    # for l in diff_list:
    #   print(l)

    # return liss, freq_val, arr
    clos(s)

def timeForLoopCounter(timeCounterArray, delay):
    timeCounter = 0
    p = 0
    for i in timeCounterArray:                               #i is index of each freq value
        if 0 <= p <= 500:
            timeCounter = timeCounter + 0.052 + delay
            p = p + 1
        if 501 <= p <=1000:
            timeCounter = timeCounter + 0.0285 + delay
            p = p + 1
        if 1001 <= p <= 1500:
            timeCounter = timeCounter + 0.0285 + delay
            p = p + 1
        if 1501 <= p <= 2000:
            timeCounter = timeCounter + 0.0285 + delay
            p = p + 1
        if 2001 <= p <= 2500:
            timeCounter = timeCounter + 0.0275 + delay
            p = p + 1
        if 2501 <= p <= 3000:
            timeCounter = timeCounter + 0.0275 + delay
            p = p + 1
        if 3001 <= p <= 3500:
            timeCounter = timeCounter + 0.0275 + delay
            p = p + 1
        if 3501 <= p <= 4000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 4001 <= p <= 4500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 4501 <= p <= 5000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 5001 <= p <= 5500:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 5501 <= p <= 6000:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 6001 <= p <= 6500:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 6501 <= p <= 7000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 7001 <= p <= 7500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 7501 <= p <= 8000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 8001 <= p <= 8500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 8501 <= p <= 9000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 9001 <= p <= 9500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 9501 <= p <= 10000:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 10001 <= p <= 10500:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 10501 <= p <= 11000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 11001 <= p <= 11500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 11501 <= p <= 12000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 12001 <= p <= 12500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 12501 <= p <= 13000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 13001 <= p <= 13501:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 13501 <= p <= 14000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 14001 <= p <= 14500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 14501 <= p <= 15000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 15001 <= p <= 15500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 15501 <= p <= 16000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 16001 <= p <= 16500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 16501 <= p <= 17000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 17001 <= p <= 17500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 17501 <+ p <= 18000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1

    # print("Time Count in seconds for TEST ", timeCounter)
    return timeCounter

def calculateTime(fileToSend):
    timeSum= 0 #initalize time counter to 0

    if fileToSend != "":
        for fileIndex in range(0, len(fileNameArray)):

            timeCounterArray = []
            with open(f"Testing_and_buffer/" + "bufferFile61Hz.csv") as csv_file:
                csv_reader = csv.DictReader(csv_file, delimiter=',')
                for rows in csv_reader:
                    y = rows['STATION_1:Freq']
                    timeCounterArray.append(float(y) + 0.01203651)
            timeSum = timeSum + timeForLoopCounter(timeCounterArray, 0.00466)


            timeCounterArray = []
            with open(f"NERC events/" + fileNameArray[fileIndex]) as csv_file:
                csv_reader = csv.DictReader(csv_file, delimiter=',')
                for rows in csv_reader:
                    y = rows['STATION_1:Freq']
                    timeCounterArray.append(float(y) + 0.01203651)
            timeSum= timeSum + timeForLoopCounter(timeCounterArray, 0.00523163)
        # print("new combined time sum is: ", timeSum)

        print("Total Time is: ", timeSum)
        return timeSum

def giveTimeToUser(estimatedTimeSeconds):
    print("the estimated time is: ",estimatedTimeSeconds)

    now = datetime.now()
    hour = now.hour
    minute = now.minute
    second = now.second
    print("Current time is: %s:%s:%s" % (hour//3600,minute % 3600 // 60,second % 60))
    currentTimeSeconds = (hour*60*60) + (minute*60) + (second)


    endTimeSeconds = currentTimeSeconds + estimatedTimeSeconds
    print("Estimate Completion Time: hr %s:min %s:sec %s" % (int(endTimeSeconds//3600), int(endTimeSeconds%3600//60), int(endTimeSeconds%60)))
    # x = datetime.timedelta(seconds=endTimeSeconds)
    # endSeconds = endTimeSeconds % (24 * 3600)
    # endHour = endTimeSeconds // (3600
    # endTimeSeconds %= 3600
    # endHour = endTimeSeconds // 60
    # endTimeSeconds %= 60

    # print("Estimate Completion Time: %", x)


    # currentTime = time.time() /
    # print("current time secs: ", currentTime)



    # now = datetime.now()
    #
    # print("now =", now)
    #
    # # dd/mm/YY H:M:S
    # dt_string = now.strftime("%H:%M:%S")
    # print("date and time =", dt_string)





fileNameArray =[]
fileNameArray = easygui.fileopenbox("Select any number of Frequency Event Event CSV Files,then press open", "", filetypes= "*.csv", multiple=True)

if fileNameArray != None:   #only read proceed to for loop if array is not empty
     for fileIndex in range(0, len(fileNameArray)):
        find_lastBackSlash = fileNameArray[fileIndex].rfind('\\')
        fileNameArray[fileIndex] = fileNameArray[fileIndex][find_lastBackSlash + 1:len(fileNameArray[fileIndex])]

print(fileNameArray)
estimatedTimeSeconds = calculateTime(fileNameArray)

giveTimeToUser(estimatedTimeSeconds)

print('Send data to grim simulator? (y/n): ')
continueToGridSim = input()

if continueToGridSim == 'y':
    startTime = time.time()
    for fileIndex in range(0, len(fileNameArray)):
            #call GS function to feed data into grid sim. Buffer will come before each event file for fileIndex in range(0, len(fileNameArray)):
            #send the buffer file first
            fileToSend = "bufferFile61Hz.csv" #buffer file is in directory
            Gs(fileToSend)                    #call GS function to feed buffer data to grim simulator

            #now send the next event file in the fileNameArray
            fileToSend = fileNameArray[fileIndex]
            Gs(fileToSend)

    endTime = time.time()
    diffTime = endTime - startTime
    print('Total run time in seconds: ', diffTime)
    now = datetime.now()
    print("Time of completion was: %s:%s:%s" % (now.hour, now.minute, now.second))

def real_time():

    liss, freq_val, arr = Gs()
    # df = pd.read_csv('freq_Gs.txt',usecols=['freq'],engine='python',index_col=None)
    y1 = [dt.datetime.now() + dt.timedelta(milliseconds=i) for i in range(len(arr))]
    y2 = [dt.datetime.now() + dt.timedelta(milliseconds=i) for i in range(len(liss))]
    # plt.plot(y1,arr)
    plt.plot(y2,freq_val)
    plt.title('Original and PMU Freq Data')
    plt.grid()
    plt.gcf().autofmt_xdate()
    plt.show()
# real_time()

# print("--- %s seconds ---" % (time.time() - start_time))