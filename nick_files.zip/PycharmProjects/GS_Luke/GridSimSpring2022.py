import csv
import socket                   #Import libraries
import time
import os
# from datetime import datetime
import datetime
import easygui


def conn():
    global s #slobal variable s allows us to send SCPI commands from anywhere in the code
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM) #Create a new socket, AF_INET = IPV4 addressed, SOCK_STREAM = TCP/IP
    s.settimeout(1000) #timeout to disconnect
    s.connect(('192.168.0.149',5025)) # NHR 9410 IP address, 5025 is port ID
    outMessage = 'SYST:RWL\n'             # Lock the touch panel screen (Safety purpose)
    s.send(outMessage.encode('utf-8'))    # For each SCPI command, it MUST encoded into utf-8.
    return s


def clos(s):                                    # This function is meant to allow local touch screen control and close socket
    outputCommand = 'SYST:LOC\n'                # unlock the touch panel screen, puts it in LOCal control mode
    s.send(outputCommand.encode('utf-8'))       # output command to unlock via utf-8
    s.close()                                   # Close the connection

start_time = time.time()

def Gs(fileToSend):

    global x
    array = []              #this will contain all frequency values, appeneded on one after the other

    with  open(fileToSend) as csv_file:  # opens the specific csv file in NERC directory
        csv_reader = csv.DictReader(csv_file, delimiter=',') #csv files have data seperated by commas
        for rows in csv_reader:                 # for each row in csv, 'rows' denotes # of total rows?
            y = rows['STATION_1:Freq']          #access the freq column in each row, assign it to 'y'
            array.append(float(y)+0.01203651)     #append that 'y' value into the array, note offset for accurate grid sim output

    conn()                                      #call function to connect to NHR grid sim
    # s.send('FREQ 60.00 \n'.encode('utf-8'))
    s.send('MACR:LEAR 1 \n'.encode('utf-8'))    #begin macro learning process
    # print("sent1")
    s.send('MACR:OPER:SYNC:INST1 SYNC \n'.encode('utf-8'))   #now begin ordering macro commands, this syncs output operation
    # print("sent2")
    s.send('MACR:LEAR 0 \n'.encode('utf-8'))                #end macro learning process
    # print("sent4")
    s.send('MACR:RUN \n'.encode('utf-8'))                   #run learned macro sequence
    output2 = "FREQ "
    liss = []
    freq_val = []
    p = 0                        #p manages array index
    j = 1                        #j will track the iteration of each freq value in .csv file

    #brake checking the script from sending frequnecy to fast. for certain ranges in array
    #we set 'x' to be a delay of a certain value for accurate frequency curve recreation
    for i in arr:
        if 0 <= p <= 500:
            #x = 0.0500
            x = 0.052
        if 501 <= p <=1000:
            x = 0.0285
        if 1501 <= p <= 2000:
            x = 0.0285
        if 2001 <= p <= 2500:
            x = 0.0275
        if 2501 <= p <= 3000:
            x = 0.0275
        if 3001 <= p <= 3500:
            x = 0.0275
        if 3501 <= p <= 4000:
            x = 0.0270
        if 4001 <= p <= 4500:
            x = 0.0270
        if 4501 <= p <= 5000:
            x = 0.0270
        if 5001 <= p <= 5500:
            x = 0.0265
        if 5501 <= p <= 6000:
            x = 0.0265
        if 6001 <= p <= 6500:
            x = 0.0265
        if 6501 <= p <= 7000:
            x = 0.0270
        if 7001 <= p <= 7500:
            x = 0.0270
        if 7501 <= p <= 8000:
            x = 0.0270
        if 8001 <= p <= 8500:
            x = 0.0270
        if 8501 <= p <= 9000:
            x = 0.0270
        if 9001 <= p <= 9500:
            x = 0.0270
        if 9501 <= p <= 10000:
            x = 0.0265
        if 10001 <= p <= 10500:
            x = 0.0265
        if 10501 <= p <= 11000:
            x = 0.0270
        if 11001 <= p <= 11500:
            x = 0.0270
        if 11501 <= p <= 12000:
            x = 0.0270
        if 12001 <= p <= 12500:
            x = 0.0270
        if 12501 <= p <= 13000:
            x = 0.0270
        if 13001 <= p <= 13501:
            x = 0.0270
        if 13501 <= p <= 14000:
            x = 0.0270
        if 14001 <= p <= 14500:
            x = 0.0270
        if 14501 <= p <= 15000:
            x = 0.0270
        if 15001 <= p <= 15500:
            x = 0.0270
        if 15501 <= p <= 16000:
            x = 0.0270
        if 16001 <= p <= 16500:
            x = 0.0270
        if 16501 <= p <= 17000:
            x = 0.0270
        if 17001 <= p <= 17500:
            x = 0.0270
        if 17501 <+ p <= 18000:
            x = 0.0270

        print('frequency value: ', round(i,5), "in file ", fileToSend, '#', j) #display freq, file, and 'j' iteration
        # start_time = time.time()
        #print('Starting time is ',start_time)
        t_wait = time.time() + x  #append 'x' to current time. This is time we wait before proceeding
        while time.time() < t_wait:  #while current time is less than the wait time, do nothing
             k = 1

        var = output2 + str(i) + '\n'  #scpi command for setting frequency is created for that array frequency value
        s.send(var.encode('utf-8'))  #send SCPI command for frequency to GS

        s.send('FREQ?\n'.encode('utf-8'))  #query message for frequency sent to GS
        msg = s.recv(1024).decode()  #GS responds with frequency value, receive and decode it
        freq_val.append(msg)
        print("response is: ", msg)   #print response from GS
        p = p + 1
        j = j + 1

    clos(s)












def timeForLoopCounter(timeCounterArray, delay):
    timeCounter = 0
    p = 0
    for i in timeCounterArray:                               #i is index of each freq value
        if 0 <= p <= 500:
            timeCounter = timeCounter + 0.052 + delay
            p = p + 1
        if 501 <= p <=1000:
            timeCounter = timeCounter + 0.0285 + delay
            p = p + 1
        if 1001 <= p <= 1500:
            timeCounter = timeCounter + 0.0285 + delay
            p = p + 1
        if 1501 <= p <= 2000:
            timeCounter = timeCounter + 0.0285 + delay
            p = p + 1
        if 2001 <= p <= 2500:
            timeCounter = timeCounter + 0.0275 + delay
            p = p + 1
        if 2501 <= p <= 3000:
            timeCounter = timeCounter + 0.0275 + delay
            p = p + 1
        if 3001 <= p <= 3500:
            timeCounter = timeCounter + 0.0275 + delay
            p = p + 1
        if 3501 <= p <= 4000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 4001 <= p <= 4500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 4501 <= p <= 5000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 5001 <= p <= 5500:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 5501 <= p <= 6000:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 6001 <= p <= 6500:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 6501 <= p <= 7000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 7001 <= p <= 7500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 7501 <= p <= 8000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 8001 <= p <= 8500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 8501 <= p <= 9000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 9001 <= p <= 9500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 9501 <= p <= 10000:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 10001 <= p <= 10500:
            timeCounter = timeCounter + 0.0265 + delay
            p = p + 1
        if 10501 <= p <= 11000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 11001 <= p <= 11500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 11501 <= p <= 12000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 12001 <= p <= 12500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 12501 <= p <= 13000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 13001 <= p <= 13501:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 13501 <= p <= 14000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 14001 <= p <= 14500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 14501 <= p <= 15000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 15001 <= p <= 15500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 15501 <= p <= 16000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 16001 <= p <= 16500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 16501 <= p <= 17000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 17001 <= p <= 17500:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1
        if 17501 <+ p <= 18000:
            timeCounter = timeCounter + 0.0270 + delay
            p = p + 1

    # print("Time Count in seconds for TEST ", timeCounter)
    return timeCounter

def calculateTime(filesToSend, bufferFileLocation61Hz):
    timeSum= 0 #initalize time counter to 0

    if filesToSend != "":   #if filesToSend is not empty
        for fileIndex in range(0, len(fileNameArray)):

            timeCounterArray = []
            with open(bufferFileLocation61Hz) as csv_file:
                csv_reader = csv.DictReader(csv_file, delimiter=',')
                for rows in csv_reader:
                    y = rows['STATION_1:Freq']
                    timeCounterArray.append(float(y) + 0.01203651)
            timeSum = timeSum + timeForLoopCounter(timeCounterArray, 0.00466)


            timeCounterArray = []
            with open(fileNameArray[fileIndex]) as csv_file:
                csv_reader = csv.DictReader(csv_file, delimiter=',')
                for rows in csv_reader:
                    y = rows['STATION_1:Freq']
                    timeCounterArray.append(float(y) + 0.01203651)
            timeSum= timeSum + timeForLoopCounter(timeCounterArray, 0.00523163)
        # print("new combined time sum is: ", timeSum)
        # print("Total Time is: ", timeSum)
        return timeSum




#this function takes the estimated seconds and displays to user in hh:mm:ss format
def giveTimeToUser(estimatedTimeSeconds):

    print("the estimated time is: ",str(datetime.timedelta(seconds = estimatedTimeSeconds)))







fileNameArray = []
#multiple=True to allow multiple csv files to be selected
fileNameArray = easygui.fileopenbox("Select any number of Frequency Event Event CSV Files,then press open", "", filetypes= "*.csv", multiple=True)

#print out each file in fileNameArray in order to be sent
print('The files selected to be sent in order are: ')
for fileIndex in range(0, len(fileNameArray)):
    print(fileNameArray[fileIndex])         #print out that index of fileNameArray
print('\n')                                 #new line

#this is the location of the buf
bufferFileLocation61Hz = r"\\frespunraid.cecs.pdx.edu\\fresp\\Spring 2022 Capstone CSV test set\\Testing Data and Buffer\\bufferFile61Hz.csv"
endBufferFileLocation59Hz = r"\\frespunraid.cecs.pdx.edu\\fresp\\Spring 2022 Capstone CSV test set\\Testing Data and Buffer\\bufferFile59Hz.csv"

estimatedTimeSeconds = calculateTime(fileNameArray, bufferFileLocation61Hz)
giveTimeToUser(estimatedTimeSeconds)




print('Send data to grim simulator? (y/n): ')
continueToGridSim = input()

if continueToGridSim == 'y':
    #will get date and test number, then will create a folder within I-Drive to store
    #a file containing ordered names of files run. This directory will also be used to
    #store RTAC recording files for the test.
    print("Enter today's date for test start: (mm-dd-yyyy)")
    todaysDate = input()

    print("Enter test number for today's date")
    print("Make sure date and test number has not been used or error will kickback: ")
    testNumber = input()
    nameOfTest= todaysDate + " Test " + testNumber

    #create folder within I-Drive w/ date and test number
    parentDirectory = r"\\frespunraid.cecs.pdx.edu\\fresp\\Spring 2022 Capstone CSV test set\\Tests"
    folderPath = os.path.join(parentDirectory, nameOfTest)
    os.mkdir(folderPath)
    print(folderPath)
    fileSentPath = 'folderPath'+'FilesSent.txt'
    #create .txt file containing names of all files/directory locations of files sent for test
    #in order selected by user
    with open(os.path.join(folderPath, "FilesSent.txt"), "w") as file:
        for fileIndex in range(0, len(fileNameArray)):
            file.write(fileNameArray[fileIndex] + '\n')
    file.close()


#now that user has entered in test info, we can set line voltage and activate grid sim output
conn()
s.send('VOLT 207.84609\n'.encode('utf-8'))
s.send('OUTP ON\n'.encode('utf-8'))
# clos(s)
time.sleep(2)

if continueToGridSim == 'y':  ##temp, should be 'y'
    startTime = time.time()
    for fileIndex in range(0, len(fileNameArray)):
            #call GS function to feed data into grid sim. Buffer will come before each event file for fileIndex in range(0, len(fileNameArray)):
            #send the buffer file first
            fileToSend = bufferFileLocation61Hz #buffer file is in directory
            Gs(fileToSend)                    #call GS function to feed buffer data to grim simulator

            #now send the next event file in the fileNameArray
            fileToSend = fileNameArray[fileIndex]
            Gs(fileToSend)

fileToSend = endBufferFileLocation59Hz
Gs(fileToSend)

# now turn off the output on grid sim
conn()
s.send('OUTP 0FF\n'.encode('utf-8'))
clos(s)

#tell user when the test ended
print("End of test: ",datetime.now())

def real_time():

    liss, freq_val, arr = Gs()
    # df = pd.read_csv('freq_Gs.txt',usecols=['freq'],engine='python',index_col=None)
    y1 = [dt.datetime.now() + dt.timedelta(milliseconds=i) for i in range(len(arr))]
    y2 = [dt.datetime.now() + dt.timedelta(milliseconds=i) for i in range(len(liss))]
    # plt.plot(y1,arr)
    plt.plot(y2,freq_val)
    plt.title('Original and PMU Freq Data')
    plt.grid()
    plt.gcf().autofmt_xdate()
    plt.show()
# real_time()

# print("--- %s seconds ---" % (time.time() - start_time))