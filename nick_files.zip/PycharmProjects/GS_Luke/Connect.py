import csv
import socket                   #Import libraries
import time
import os
import datetime as dt
#re
def conn():
    global s
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.settimeout(1000)
    s.connect(('192.168.0.149',5025)) # NHR 9410 IP address
    output = 'SYST:RWL\n'             # Lock the touch panel screen (Safety purpose)
    s.send(output.encode('utf-8'))    # For each SCPI command, it MUST encoded into utf-8.
    return s
