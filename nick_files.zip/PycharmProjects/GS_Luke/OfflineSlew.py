import datetime as datetime
import pandas as pd
import numpy as np  # Might need this for Albdul's Algorithm
import csv
from datetime import datetime # for setting date time data in pandas
import matplotlib.pyplot as plt # Plotting functions

import math
import os
import time
import random


def data_handle():
    # val_path = r'E:\Study\Engineering\MS USA\Power Engineering Lab\Fresp\2021 algo\\'
    # # This is the file that has the validation set responses to the file names(col 1) and is event (col 7)
    # fnm1 = 'Human Validation 3.csv'
    # df1 = pd.read_csv(val_path + fnm1)
    # global name, is_eventH
    # name = df1['Name']
    # is_eventH = df1['Is_event']
    #
    # path1 = r'E:\Study\Engineering\MS USA\Power Engineering Lab\Fresp\2021 algo\test files 3\\'
    #


    #Here the user will be prompted to select enter test name info
    print("Enter the date test was ran: (mm-dd-yyyy): ")
    todaysDate = input()
    dateArray = todaysDate.split("-")
    print("Enter test number for test date: ")
    testNumber = input()
    testName = todaysDate + " Test " + testNumber

    # the order of csv files to be sent will be read from file path into array, line by line
    testPath = "I:\\FRESP\\Spring 2022 Capstone CSV test set\\Tests\\" + testName + "\\"
    nameOfCSV = []  # declare array to be used for file order sent
    with open(testPath + "FilesSent.txt") as fileSent:
        for j in fileSent:
            nameOfCSV.append(j[:-1]) #remove the last \n charachter for new line. dataframe won't open with it present


    file_name = []
    global freq_original, slew, slew_windowVal
    freq_original = []
    slew = []
    # print("Enter the slew window here: ")
    # slew_windowVal = input()

    for i in range(len(nameOfCSV)):
        # fnm = name[i]
        # file_name.append(fnm)  # FIle name to save for writing out to csv to store Event=T/F & Under/Over frequency
        # # Creating the dataframe for the PMU csv file and Parsing data
        # df = pd.read_csv(nameOfCSV[i], delimiter=',', low_memory=False)
        df = pd.read_csv(nameOfCSV[i], delimiter=',', low_memory=False)

        print(df)
        # Timestamp = df['Timestamp']
        freq_original.append(df['STATION_1:Freq'])

        ts_ph = np.linspace(0, len(freq_original[i]), len(freq_original[i]))
        slew.append(slew_calc(170, ts_ph, freq_original[i], nameOfCSV[i]))
        print(slew)
        print("length of slew is: ", len(slew[0]))
        print("The file opened is: ", nameOfCSV[i])
        print("Press anything to continue on: ")
        print(slew[0][0])
        print(slew[0][1])
        print(slew[0][2])
        dummy = input()

    sparse(freq_original, slew)

def slew_calc(slew_window, ts_ph, Freq, file_name, memo = {}):
    try:
        return memo[(slew_window, file_name)]
    except KeyError:
        sum_ts = []
        sum_freq = []
        sum_tsfreq = []
        sum_ts2 = []
        slew = []
        intercept = []
        line = []
        print("slew window: ",slew_window)
        for j in range(len(Freq)):
            if j + slew_window > len(Freq):
                break
            else:
                sum_ts.append(np.sum(ts_ph[j:j + slew_window]))
                sum_freq.append(np.sum(Freq[j:j + slew_window]))
                sum_tsfreq.append(np.sum(ts_ph[j:j + slew_window] * Freq[j:j + slew_window]))
                sum_ts2.append(np.sum(ts_ph[j:j + slew_window] * ts_ph[j:j + slew_window]))
                slew.append((slew_window * sum_tsfreq[j] - sum_ts[j] * sum_freq[j]) / (slew_window * sum_ts2[j] - sum_ts[j] * sum_ts[j]))
                intercept.append((sum_freq[j] - slew[j] * sum_ts[j]) / slew_window)
                line.append(slew[j] * ts_ph[j] + intercept[j])
        memo[(slew_window, file_name)] = slew
        return slew


def sparse(freq_original, slew):
    global Freq, y2, slew_short
    Freq = []
    y2 = []
    slew_short = []
    for i in range(len(slew)):
        freq_temp = []
        maximum = max(slew[i])
        minimum = min(slew[i])
        f = freq_original[i]
        max_index = list(slew[i]).index(maximum)
        min_index = list(slew[i]).index(minimum)

        x1_max = max_index - 3000
        x2_max = max_index + 3000
        if x1_max < 0:
            x1_max = 0
        if x2_max > len(f)-1:
            x2_max = len(f)-1

        x1_min = min_index - 3000
        x2_min = min_index + 3000
        if x1_min < 0:
            x1_min = 0
        if x2_min > len(f)-1:
            x2_min = len(f)-1

        # if maximum >= 60.03:
        #     for j in range(x_max, y_max):
        #         freq_temp.append(f[j])
        # elif minimum <= 59.97:
        #     for j in range(x_min, y_min):
        #         freq_temp.append(f[j])
        # elif maximum >= 60.02:
        #     for j in range(x_max, y_max):
        #         freq_temp.append(f[j])
        # elif minimum <= 59.98:
        #     for j in range(x_min, y_min):
        #         freq_temp.append(f[j])
        arr = []
        if abs(maximum-0.0) > abs(minimum-0.0):
            for j in range(x1_max, x2_max):
                freq_temp.append(f[j])
                arr.append(j)
        elif abs(maximum-0.0) <= abs(minimum-0.0):
            for j in range(x1_min, x2_min):
                freq_temp.append(f[j])
                arr.append(j)

        y2.append(arr)
        Freq.append(freq_temp)
    for i in range(len(name)):
        ts_ph = np.linspace(0, len(Freq[i]), len(Freq[i]))
        slew_short.append(slew_calc(200, ts_ph, Freq[i], name[i]))


data_handle()


# # for x in range(len(name)):
# x = 9
# y1 = range(len(freq_original[x]))
# # y2 = range(len(Freq[x]))
# y2 = range(len(slew[x]))
#
# plot1 = plt.figure(1)
# plt.plot(y1, freq_original[x])
# plt.title(f'Original file {x}')
#
# plot2 = plt.figure(2)
# plt.plot(y2, slew[x])
# plt.title(f'Short file {x}')
# plt.grid()
# plt.show()