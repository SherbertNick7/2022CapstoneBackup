import csv
import socket                   #Import libraries
import time
import os
import datetime as dt
import easygui

from matplotlib import pyplot as plt


# os.nice(-20)

def conn():
    global s                                                #Define global variable s, where we can use to send SCPI commands from anywhere
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)   #AF_INET for IPV4 addresses, SOCK_STREAM for TCP/IP
    s.settimeout(1000)                                      #timeout before connection is lost
    s.connect(('192.168.0.149',5025)) # NHR 9410 IP address, 5025 port ID
    output = 'SYST:RWL\n'             # Lock the touch panel screen (Safety purpose)
    s.send(output.encode('utf-8'))    # For each SCPI command, it MUST encoded into utf-8.
    return s


def clos(s):                              # This function is meant to close the connection
    output5 = 'SYST:LOC\n'                #Put HMI screen in LOCal control
    s.send(output5.encode('utf-8'))       # send the SCPI command to GS
    s.close()                             # this closes socket sonnection



def Gs(freqArray, j):
    global x                                    # x is used for delay of sending frequency values to GS
    conn()                                      #call function to connect to NHR grid sim
    # s.send('FREQ 60.00 \n'.encode('utf-8'))
    s.send('MACR:LEAR 1 \n'.encode('utf-8'))    #begin macro learning process
    # print("sent1")
    s.send('MACR:OPER:SYNC:INST1 SYNC \n'.encode('utf-8'))   #now begin ordering macro commands, this syncs output operation
    # print("sent2")
    s.send('MACR:LEAR 0 \n'.encode('utf-8'))                #end macro learning process
    # print("sent4")
    s.send('MACR:RUN \n'.encode('utf-8'))                   #
    # print("sent5")n
    output2 = 'FREQ '
    # liss = []
    freq_val = []
    p = 0
    ArrayIndex = 0
    timeSum = 0
    for i in freqArray:                               #i is index of each freq value
        if 0 <= p <= 500:
            #x = 0.0500
            x = 0.052
        if 501 <= p <=1000:
            x = 0.0285
        if 1001 <= p <= 1500:
            x = 0.0285
        if 1501 <= p <= 2000:
            x = 0.0285
        if 2001 <= p <= 2500:
            x = 0.0275
        if 2501 <= p <= 3000:
            x = 0.0275
        if 3001 <= p <= 3500:
            x = 0.0275
        if 3501 <= p <= 4000:
            x = 0.0270
        if 4001 <= p <= 4500:
            x = 0.0270
        if 4501 <= p <= 5000:
            x = 0.0270
        if 5001 <= p <= 5500:
            x = 0.0265
        if 5501 <= p <= 6000:
            x = 0.0265
        if 6001 <= p <= 6500:
            x = 0.0265
        if 6501 <= p <= 7000:
            x = 0.0270
        if 7001 <= p <= 7500:
            x = 0.0270
        if 7501 <= p <= 8000:
            x = 0.0270
        if 8001 <= p <= 8500:
            x = 0.0270
        if 8501 <= p <= 9000:
            x = 0.0270
        if 9001 <= p <= 9500:
            x = 0.0270
        if 9501 <= p <= 10000:
            x = 0.0265
        if 10001 <= p <= 10500:
            x = 0.0265
        if 10501 <= p <= 11000:
            x = 0.0270
        if 11001 <= p <= 11500:
            x = 0.0270
        if 11501 <= p <= 12000:
            x = 0.0270
        if 12001 <= p <= 12500:
            x = 0.0270
        if 12501 <= p <= 13000:
            x = 0.0270
        if 13001 <= p <= 13501:
            x = 0.0270
        if 13501 <= p <= 14000:
            x = 0.0270
        if 14001 <= p <= 14500:
            x = 0.0270
        if 14501 <= p <= 15000:
            x = 0.0270
        if 15001 <= p <= 15500:
            x = 0.0270
        if 15501 <= p <= 16000:
            x = 0.0270
        if 16001 <= p <= 16500:
            x = 0.0270
        if 16501 <= p <= 17000:
            x = 0.0270
        if 17001 <= p <= 17500:
            x = 0.0270
        if 17501 <+ p <= 18000:
            x = 0.0270
        # print('frequency value: ', i, "in file ", fileToSend)
        start_time = time.time()
        #print('Starting time is ',start_time)
        t_end = time.time() + x
        timeSum = timeSum + x
        while time.time() < t_end:
            k = 1
        var = output2 + str(i) + '\n'
        # print(var)
        s.send(var.encode('utf-8'))
        end_time = time.time()
        # print('Time ends here ',end_time)
        diff = end_time - start_time
        # print(diff)
        diff_list = liss.append(diff)
        s.send('FREQ?\n'.encode('utf-8'))
        msg = s.recv(1024).decode()
        freq_val.append(msg)
        p = p + 1

        print('Iteration : ', j)
        print("Array Index: ", ArrayIndex)
        print('response: ', msg)
        ArrayIndex = ArrayIndex + 1
    # for l in diff_list:
    #   print(l)

    # return liss, freq_val, arr
    clos(s)


        # print('response: ', msg)
    # for l in diff_list:
    #   print(l)

    # # return liss, freq_val, arr
    # clos(s)
    # end_time = time.time()
    # diff = end_time - startTime

    return timeSum

# def averageTime(timeArray):
#
#     totalValueSet = len(timeArray)
#     sum = 0
#
#     for j in timeArray:
#         sum = sum + j
#
#     average = sum/totalValueSet
#
#     return average

def calculateTimeDelay(actualTime,expectedTime,iterationCounter):
    averageDelaySample = (actualTime - expectedTime)/iterationCounter

    return averageDelaySample





def averageTotalDelayTime(sampleAverageDelayArray, numSamples):
    sum = 0
    for i in sampleAverageDelayArray:
        sum = sum + i

    average = sum/numSamples

    print("Final average is: ", average)

    return average


startDataPoints = 20#how many data points to start with
endDataPoints = 21  #how many data points to end with
freqValue = 61       #freq to populate freqArray with
freqArray = []
numSamples = 25      #number of times to record time takes to send each freqArray though to grid sim
delayTimeArray = []       #will find the delayTime for each iteration
sampleAverageDelayArray= []  #average Delay Time Array
delayTimeAverageArray = []  #delta
# expectedTimeArray = []

for i in range(0, startDataPoints):
    freqArray.append(freqValue)

iterationCounter = startDataPoints
# timeComplete= 0


while(iterationCounter <= endDataPoints):

#this will record time it takes for a certain freqArray length of 60 Hz to go though grid sim. Will record time it takes
#to run though each iteration, find then subtract the expected time to run, then calculate average delay for each freq
#datapoint
    for j in range(0,numSamples):  #will run each length of freqArray for nUmSample times,
        timeStarted= time.time()  #start recording time
        expectedTime = Gs(freqArray, j)             #send freq array to GS, wait for it to complete, also return uncorrected time
        timeEnded = time.time()   #record stop time
        actualTime = timeEnded - timeStarted  #take difference to find actual time it takes to run array though Grid sim
        sampleAverageDelay = calculateTimeDelay(actualTime,expectedTime,iterationCounter)# timeArray.append(diffTime)
        print("main loop sample average: ", sampleAverageDelay)
        sampleAverageDelayArray.append(sampleAverageDelay)


        # time.sleep(0.1)   #brief delay before resuming
        timeStarted = 0  #reset this to 0 for next iteration
        timeEnded = 0


    calculatedAverageDelayTime = averageTotalDelayTime(sampleAverageDelayArray, numSamples)
    delayTimeAverageArray.append(calculatedAverageDelayTime)


    #now increment the length of freqArray
    freqArray.append(freqValue)
    iterationCounter = iterationCounter + 1
    timeStarted = 0 #reset time to 0 for next test
    timeEnded = 0

    iterationCounter = iterationCounter + 1


# print(timeArray)
# print(averageTimeArray)

# for k in range(0,len(averageTimeArray)):
#     calculateTimeDelay(averageTimeArray[k])




