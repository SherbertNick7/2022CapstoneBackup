import csv
import socket                   #Import libraries
import time
import os
import datetime as dt
from matplotlib import pyplot as plt


# os.nice(-20)

def conn():
    global s
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.settimeout(1000)
    s.connect(('192.168.0.149',5025)) # NHR 9410 IP address
    output = 'SYST:RWL\n'             # Lock the touch panel screen (Safety purpose)
    s.send(output.encode('utf-8'))    # For each SCPI command, it MUST encoded into utf-8.
    return s


def clos(s):                              # This function is meant to close the connection
    output5 = 'SYST:LOC\n'            # Unlock the touch panel screen
    s.send(output5.encode('utf-8'))
    s.close()                         # Close the connection

start_time = time.time()

def Gs(iteration):

    global x
    arr = []
    with open(f"{iteration}.csv") as csv_file:
        csv_reader = csv.DictReader(csv_file, delimiter=',')
        for rows in csv_reader:
            y = rows['STATION_1:Freq']
            arr.append(float(y)+0.01203651)

    conn()
    # s.send('FREQ 60.00 \n'.encode('utf-8'))
    s.send('MACR:LEAR 1 \n'.encode('utf-8'))
    # print("sent1")
    s.send('MACR:OPER:SYNC:INST1 SYNC \n'.encode('utf-8'))
    # print("sent2")
    s.send('MACR:LEAR 0 \n'.encode('utf-8'))
    # print("sent4")
    s.send('MACR:RUN \n'.encode('utf-8'))
    # print("sent5")
    output2 = 'FREQ '
    liss = []
    freq_val = []
    p = 0 #p is the position in frequency array
    for i in arr:
        if 0 <= p <= 500:
            #x = 0.0500
            x = 0.052
        if 501 <= p <=1000:
            x = 0.0285
        if 1501 <= p <= 2000:
            x = 0.0285
        if 2001 <= p <= 2500:
            x = 0.0275
        if 2501 <= p <= 3000:
            x = 0.0275
        if 3001 <= p <= 3500:
            x = 0.0275
        if 3501 <= p <= 4000:
            x = 0.0270
        if 4001 <= p <= 4500:
            x = 0.0270
        if 4501 <= p <= 5000:
            x = 0.0270
        if 5001 <= p <= 5500:
            x = 0.0265
        if 5501 <= p <= 6000:
            x = 0.0265
        if 6001 <= p <= 6500:
            x = 0.0265
        if 6501 <= p <= 7000:
            x = 0.0270
        if 7001 <= p <= 7500:
            x = 0.0270
        if 7501 <= p <= 8000:
            x = 0.0270
        if 8001 <= p <= 8500:
            x = 0.0270
        if 8501 <= p <= 9000:
            x = 0.0270
        if 9001 <= p <= 9500:
            x = 0.0270
        if 9501 <= p <= 10000:
            x = 0.0265
        if 10001 <= p <= 10500:
            x = 0.0265
        if 10501 <= p <= 11000:
            x = 0.0270
        if 11001 <= p <= 11500:
            x = 0.0270
        if 11501 <= p <= 12000:
            x = 0.0270
        if 12001 <= p <= 12500:
            x = 0.0270
        if 12501 <= p <= 13000:
            x = 0.0270
        if 13001 <= p <= 13501:
            x = 0.0270
        if 13501 <= p <= 14000:
            x = 0.0270
        if 14001 <= p <= 14500:
            x = 0.0270
        if 14501 <= p <= 15000:
            x = 0.0270
        if 15001 <= p <= 15500:
            x = 0.0270
        if 15501 <= p <= 16000:
            x = 0.0270
        if 16001 <= p <= 16500:
            x = 0.0270
        if 16501 <= p <= 17000:
            x = 0.0270
        if 17001 <= p <= 17500:
            x = 0.0270
        if 17501 <+ p <= 18000:
            x = 0.0270
        print('frequency value: ',i)
        start_time = time.time()
        # print('Starting time is ',start_time)
        t_end = time.time() + x         #the current time + 'x' delay from for loop above is time to wait until
        while time.time() < t_end:      #wait until the current time (time.time) is equal or greater than t_end, k does nothing
            k = 1                       #when t_end is not greater, then proceed with sending next freq val
        var = output2 + str(i)+'\n'
        # print(var)
        s.send(var.encode('utf-8'))
        end_time = time.time()
        # print('Time ends here ',end_time)
        diff = end_time - start_time
        #print(diff)
        diff_list = liss.append(diff)
        s.send('FREQ?\n'.encode('utf-8'))
        msg = s.recv(1024).decode()
        freq_val.append(msg)
        p = p + 1

        print('response: ',msg)
    # for l in diff_list:
    #   print(l)

    # return liss, freq_val, arr
    clos(s)

iteration=1
while iteration<=1:
    Gs(iteration)
    iteration+=1

def real_time():

    liss, freq_val, arr = Gs()
    df = pd.read_csv('freq_Gs.txt',usecols=['freq'],engine='python',index_col=None)
    y1 = [dt.datetime.now() + dt.timedelta(milliseconds=i) for i in range(len(arr))]
    y2 = [dt.datetime.now() + dt.timedelta(milliseconds=i) for i in range(len(liss))]
    plt.plot(y1,arr)
    plt.plot(y2,freq_val)
    plt.title('Original and PMU Freq Data')
    plt.grid()
    plt.gcf().autofmt_xdate()
    plt.show()

# real_time()

print("--- %s seconds ---" % (time.time() - start_time))